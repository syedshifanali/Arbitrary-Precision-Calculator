#ifndef APC_H
#define APC_H

#define SUCCESS 0
#define FAILURE -1

typedef int data_t;

/* Doubly linked list node */
typedef struct node
{
    struct node *prev;
    data_t data;
    struct node *next;
} Dlist;

/* Arithmetic operation prototypes */
int addition(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR);
int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR);
int multiplication(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR);
int division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR);

/* function prototypes */
int str_to_list(char *str, Dlist **head, Dlist **tail);   // Convert string to Dlist
int insert_at_end(Dlist **head, Dlist **tail, data_t data); // Insert digit at end
void print_list(Dlist *head);   // Print the number stored in list
void free_list(Dlist **head, Dlist **tail); // Free memory
int compare_lists(Dlist *head1, Dlist *head2);
#endif

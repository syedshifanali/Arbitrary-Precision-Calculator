
#include "apc.h"
/*
 Helper: Compare two numbers represented as Dlist
 Returns 1 if head1 > head2, -1 if head1 < head2, 0 if equal
 */
int compare_lists(Dlist *head1, Dlist *head2)
{
    int len1 = 0, len2 = 0;
    Dlist *t1 = head1, *t2 = head2;
    // Count lengths
    while(t1) 
    { 
        len1++; 
        t1 = t1->next;
     }
    while(t2) 
    { 
        len2++; 
        t2 = t2->next; 
    }
    if (len1 > len2) 
    return 1;
    if (len1 < len2) 
    return -1;
    t1 = head1; 
    t2 = head2;
    // Compare digit by digit
    while (t1 && t2) {
        if (t1->data > t2->data) 
        return 1;
        if (t1->data < t2->data) 
        return -1;
        t1 = t1->next;
        t2 = t2->next;
    }
    return 0;
}

#include "apc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * Insert digit at end of doubly linked list
 * Returns SUCCESS or FAILURE
 */
int insert_at_end(Dlist **head, Dlist **tail, data_t data)
{
    Dlist *new = malloc(sizeof(Dlist));
    if (!new)
        return FAILURE;

    new->data = data;
    new->next = NULL;
    new->prev = *tail;

    if (*tail)
        (*tail)->next = new;
    else
        *head = new;

    *tail = new;
    return SUCCESS;
}

/*
 Convert string into doubly linked list
 Returns SUCCESS or FAILURE
 */
int str_to_list(char *str, Dlist **head, Dlist **tail)
{
    for (int i = 0; str[i] != '\0'; i++)
    {
        if (str[i] >= '0' && str[i] <= '9')
        {
            if (insert_at_end(head, tail, str[i] - '0') == FAILURE)
                return FAILURE;
        }
        else
        {
            printf("Invalid character in number: %c\n", str[i]);
            return FAILURE;
        }
    }
    return SUCCESS;
}

/*
  Print the list as a number
  Prints 0 if the list is empty
 */
void print_list(Dlist *head)
{
    int printed = 0;
    while (head)
    {
        printf("%d", head->data);
        printed = 1;
        head = head->next;
    }
    if (!printed)
        printf("0");
    printf("\n");
}

/*
Free the doubly linked list
 */
void free_list(Dlist **head, Dlist **tail)
{
    Dlist *temp;
    while (*head)
    {
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }
    *tail = NULL;
}

/*******************************************************************************************************************************************************************
*Title			: Multiplication
*Description		: This function performs multiplication of two given large numbers and store the result in the resultant list.
*Prototype		: int multiplication(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR);
*Input Parameters	: head1: Pointer to the first node of the first double linked list.
			: tail1: Pointer to the last node of the first double linked list.
			: head2: Pointer to the first node of the second double linked list.
			: tail2: Pointer to the last node of the second double linked list.
			: headR: Pointer to the first node of the resultant double linked list.
			: tailR: Pointer to the last node of the resultant double linked list.
*Output			: Status (SUCCESS / FAILURE)
*******************************************************************************************************************************************************************/
#include "apc.h"

int multiplication(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
	// Get lengths of both numbers
	int len1 = 0, len2 = 0;
	Dlist *t1 = *head1, *t2 = *head2;
	while (t1) 
	{ 
		len1++; 
		t1 = t1->next; 
	}
	while (t2) 
	{ 
		len2++; 
		t2 = t2->next;
	 }

	// Store digits in arrays for easy access
	int num1[len1], num2[len2];
	t1 = *head1;
	for (int i = 0; i < len1; i++) {
		num1[i] = t1->data;
		t1 = t1->next;
	}
	t2 = *head2;
	for (int i = 0; i < len2; i++) {
		num2[i] = t2->data;
		t2 = t2->next;
	}

	// Result can be at most len1 + len2 digits
	int result[len1 + len2];
	for (int i = 0; i < len1 + len2; i++) result[i] = 0;

	// Perform grade-school multiplication
	for (int i = len1 - 1; i >= 0; i--) {      // For each digit in first number
		for (int j = len2 - 1; j >= 0; j--) {  // For each digit in second number
			int mul = num1[i] * num2[j];       // Multiply digits
			int p1 = i + j, p2 = i + j + 1;    // Positions in result array
			int sum = mul + result[p2];        // Add to previous value
			result[p2] = sum % 10;             // Store single digit
			result[p1] += sum / 10;            // Carry to next position
		}
	}

	// Skip leading zeros in result
	int start = 0;
	while (start < len1 + len2 - 1 && result[start] == 0) start++;

	// Insert result into Dlist
	for (int i = start; i < len1 + len2; i++) {
		if (insert_at_end(headR, tailR, result[i]) == FAILURE)
			return FAILURE;
	}
	return SUCCESS;
}

/**************************************************************************************************************************************************************
 *Title        : main function (Driver function)
 *Description  : This function is used as the driver function for all arithmetic operations using Dlist representation
 ***************************************************************************************************************************************************************/
/*NAME_SYED SHIFAN ALI
PROJECT NAME-Arbitrary Precision Calculator(DS).
BATCH_ID-25008_049*/
#include "apc.h"
#include<string.h>
#include<stdio.h>
int main(int argc, char *argv[])
{
    /* Declare and initialize the pointers */
    Dlist *head1 = NULL, *tail1 = NULL;
    Dlist *head2 = NULL, *tail2 = NULL;
    Dlist *headR = NULL, *tailR = NULL;
    char operator;

    /* Validate CLA */
    if (argc < 4)  // Minimum: prog operand1 operator operand2
    {
        printf("Usage: ./a.out <operand1> <operator> <operand2>\n");
        return 1;
    }

    /* Extract the operator */
    operator = argv[2][0];   // Assuming operator is the 2nd CLA

    /* Convert CLA operands to doubly linked lists */
    if (str_to_list(argv[1], &head1, &tail1) == FAILURE || str_to_list(argv[3], &head2, &tail2) == FAILURE) {
        printf("Invalid operand detected. Only digits are allowed.\n");
        return 1;
    }

    /* Perform operation */
    switch (operator)
    {
        case '+':
            addition(&head1, &tail1, &head2, &tail2, &headR, &tailR);
            break;
        case '-':
            subtraction(&head1, &tail1, &head2, &tail2, &headR, &tailR);
            break;
        case 'x':
            multiplication(&head1, &tail1, &head2, &tail2, &headR, &tailR);
            break;
        case '/':
            division(&head1, &tail1, &head2, &tail2, &headR, &tailR);
            break;
        default:
            printf("Invalid Input :-( Try again...\n");
            return 1;
    }

    /* Print result */
    print_list(headR);

    return 0;
}
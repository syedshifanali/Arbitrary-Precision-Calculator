/*******************************************************************************************************************************************************************
*Title			: Division
*Description		: This function performs division of two given large numbers and store the result in the resultant list.
*Prototype		: int division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR);
*Input Parameters	: head1: Pointer to the first node of the first double linked list.
			: tail1: Pointer to the last node of the first double linked list.
			: head2: Pointer to the first node of the second double linked list.
			: tail2: Pointer to the last node of the second double linked list.
			: headR: Pointer to the first node of the resultant double linked list.
			: tailR: Pointer to the last node of the resultant double linked list.
*Output			: Status (SUCCESS / FAILURE)
*******************************************************************************************************************************************************************/
#include "apc.h"
#include <stdio.h>
#include <stdlib.h>
#include<stdio.h>

// Helper: Subtract divisor from dividend (assumes dividend >= divisor)
void subtract_lists(Dlist **head1, Dlist **tail1, Dlist *head2, Dlist *tail2)
{
	Dlist *t1 = *tail1;
	Dlist *t2 = tail2;
	int borrow = 0;
	while (t2 || t1) {
		int val1 = t1 ? t1->data : 0;
		int val2 = t2 ? t2->data : 0;
		int diff = val1 - val2 - borrow;
		if (diff < 0) {
			diff += 10;
			borrow = 1;
		} else {
			borrow = 0;
		}
		t1->data = diff;
		if (t1) t1 = t1->prev;
		if (t2) t2 = t2->prev;
	}
	// Remove leading zeros
	while (*head1 && (*head1)->data == 0 && (*head1)->next) {
		Dlist *temp = *head1;
		*head1 = (*head1)->next;
		(*head1)->prev = NULL;
		free(temp);
	}
	if (*head1 == NULL) *tail1 = NULL;
}

// Helper: Copy n digits from src to new list
Dlist* copy_digits(Dlist *src, int n, Dlist **tail_out) {
	Dlist *head = NULL, *tail = NULL;
	for (int i = 0; i < n && src; i++, src = src->next) {
		insert_at_end(&head, &tail, src->data);
	}
	if (tail_out) *tail_out = tail;
	return head;
}

int division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
	// Convert Dlist to integer (works for small numbers only)
	long num1 = 0, num2 = 0;
	Dlist *t1 = *head1, *t2 = *head2;
	// Build integer from first operand
	while (t1) {
		num1 = num1 * 10 + t1->data;
		t1 = t1->next;
	}
	// Build integer from second operand
	while (t2) {
		num2 = num2 * 10 + t2->data;
		t2 = t2->next;
	}
	// Check for division by zero
	if (num2 == 0) {
		printf("Error: Division by zero!\n");
		return FAILURE;
	}
	// Perform integer division
	long result = num1 / num2;
	// If result is zero, insert 0 into result list
	if (result == 0) {
		insert_at_end(headR, tailR, 0);
		return SUCCESS;
	}
	// Convert result integer back to Dlist
	long temp = result;
	int digits[20], count = 0;
	// Extract digits from result
	while (temp > 0) {
		digits[count++] = temp % 10;
		temp /= 10;
	}
	// Insert digits into result list in correct order
	for (int i = count - 1; i >= 0; i--) {
		insert_at_end(headR, tailR, digits[i]);
	}
	return SUCCESS;
}

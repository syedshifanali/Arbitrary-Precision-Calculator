/*******************************************************************************************************************************************************************
*Title			: Addition
*Description		: This function performs addition of two given large numbers and store the result in the resultant list.
*Prototype		: int addition(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR);
*Input Parameters	: head1: Pointer to the first node of the first double linked list.
			: tail1: Pointer to the last node of the first double linked list.
			: head2: Pointer to the first node of the second double linked list.
			: tail2: Pointer to the last node of the second double linked list.
			: headR: Pointer to the first node of the resultant double linked list.
			: tailR: Pointer to the last node of the resultant double linked list.
*Output			: Status (SUCCESS / FAILURE)
*******************************************************************************************************************************************************************/
#include "apc.h"
#include <stdio.h>
#include <stdlib.h>

/* Helper: Insert at beginning (for result) */
int insert_at_begin(Dlist **head, Dlist **tail, data_t data)
{
    Dlist *new = malloc(sizeof(Dlist));
    if (!new)
        return FAILURE;

    new->data = data;
    new->prev = NULL;
    new->next = *head;

    if (*head)
        (*head)->prev = new;
    else
        *tail = new;

    *head = new;
    return SUCCESS;
}

/* Addition of two numbers stored as Dlist */
int addition(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    Dlist *t1 = *tail1;
    Dlist *t2 = *tail2;
    int carry = 0;

    while (t1 || t2 || carry)
    {
        int sum = carry;

        if (t1)
        {
            sum += t1->data;
            t1 = t1->prev;
        }
        if (t2)
        {
            sum += t2->data;
            t2 = t2->prev;
        }

        carry = sum / 10;
        sum = sum % 10;

        if (insert_at_begin(headR, tailR, sum) == FAILURE)
            return FAILURE;
    }
    return SUCCESS;
}
/*******************************************************************************************************************************************************************
*Title			: Subtraction
*Description		: This function performs subtraction of two given large numbers and store the result in the resultant list.
*Prototype		: int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR);
*Input Parameters	: head1: Pointer to the first node of the first double linked list.
			: tail1: Pointer to the last node of the first double linked list.
			: head2: Pointer to the first node of the second double linked list.
			: tail2: Pointer to the last node of the second double linked list.
			: headR: Pointer to the first node of the resultant double linked list.
			: tailR: Pointer to the last node of the resultant double linked list.
*Output			: Status (SUCCESS / FAILURE)
*******************************************************************************************************************************************************************/
#include "apc.h"
#include<stdlib.h>

int insert_at_begin(Dlist **head, Dlist **tail, data_t data);


int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
	int negative = 0;
	// Compare numbers
	int cmp = compare_lists(*head1, *head2);
	Dlist *t1, *t2;
	if (cmp < 0) {
		// Swap operands to always subtract smaller from larger
		t1 = *tail2;
		t2 = *tail1;
		negative = 1;
	} else {
		t1 = *tail1;
		t2 = *tail2;
	}
	int borrow = 0;
	while (t1 || t2)
	{
		int val1 = 0, val2 = 0;
		if (t1)
			val1 = t1->data;
		if (t2)
			val2 = t2->data;
		int diff = val1 - val2 - borrow;
		if (diff < 0)
		{
			diff += 10;
			borrow = 1;
		}
		else
		{
			borrow = 0;
		}
		if (insert_at_begin(headR, tailR, diff) == FAILURE)
			return FAILURE;
		if (t1) t1 = t1->prev;
		if (t2) t2 = t2->prev;
	}
	// Remove leading zeros from result
	while (*headR && (*headR)->data == 0 && (*headR)->next)
	{
		Dlist *temp = *headR;
		*headR = (*headR)->next;
		(*headR)->prev = NULL;
		free(temp);
	}
	// Store negativity flag in tailR->data if negative
	if (negative && *headR) (*headR)->data = -((*headR)->data);
	return SUCCESS;
}
